
var modal = document.getElementById("loginModal");
var btn = document.getElementById("loginBtn");
var span = document.getElementsByClassName("close")[0];

// mở login khi ấn biểu tượng
btn.onclick = function() {
    modal.style.display = "block";
}

// khi ấn X thì đóng
span.onclick = function() {
    modal.style.display = "none";
}

// khi ấn ra ngoài thì phần login đóng
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}