let cartCount = 0;

function addToCart(productName) {
    cartCount++;
    updateCartDisplay();
    alert(productName + " đã được thêm vào giỏ hàng!"); 
}

function updateCartDisplay() {
    const cartDisplay = document.getElementById('cart-count');
    if (cartDisplay) {
        cartDisplay.querySelector('a').textContent = `Giỏ hàng (${cartCount})`;
    }
}