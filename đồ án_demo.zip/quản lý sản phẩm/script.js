let products = ["YZF-R15", "Yamaha MT 09", "MV Agusta Rivale", "YZF-R3 2024", "Z900 ABS", "Ninja H2R"];

/* Hàm hiển thị danh sách sản phẩm */
function displayProducts() {
    const app = document.getElementById("app");
    app.innerHTML = `
    </table>
        <form id="addForm" onsubmit="addProduct(event)" style="text-align: center;">
            <input type="text" id="newProduct" placeholder="Tên sản phẩm mới" required>
            <button type="submit">Thêm</button>
        </form>
        <div id="editForm" style="display: none; text-align: center;">
            <input type="text" id="editProductName" required>
            <button onclick="updateProduct()">Sửa</button>
        </div>
        <table>
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Tên sản phẩm</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                ${products.map((product, index) => `
                    <tr>
                        <td>${index + 1}</td>
                        <td>${product}</td>
                        <td>
                            <button onclick="editProduct(${index})">Sửa</button>
                            <button onclick="deleteProduct(${index})">Xóa</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        
    `;
}

/* Hàm thêm sản phẩm */
function addProduct(event) {
    event.preventDefault();
    const newProduct = document.getElementById("newProduct").value;
    products.push(newProduct);
    alert("Thêm sản phẩm thành công!");
    displayProducts();
}

/* Hàm sửa sp */
let currentEditIndex = -1;

function editProduct(index) {
    currentEditIndex = index;
    const editForm = document.getElementById("editForm");
    document.getElementById("editProductName").value = products[index];
    editForm.style.display = "block";
}


function updateProduct() {
    const updatedName = document.getElementById("editProductName").value;
    if (currentEditIndex !== -1) {
        products[currentEditIndex] = updatedName;
        alert("Cập nhật sản phẩm thành công!");
        displayProducts();
    }
}

/* Hàm xóa sp */
function deleteProduct(index) {
    if (confirm("Bạn có chắc muốn xóa sản phẩm này?")) {
        products.splice(index, 1);
        alert("Xóa sản phẩm thành công!");
        displayProducts();
    }
}

displayProducts();
